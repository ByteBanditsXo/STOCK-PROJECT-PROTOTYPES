class Config:
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///stock_data.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
